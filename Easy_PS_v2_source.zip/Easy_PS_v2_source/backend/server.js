import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "node:crypto";
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const clients = new Map();
const jobs = new Map();

function adminAuth(req, res, next) {
  const expected = process.env.ADMIN_API_KEY || "";
  const supplied = req.header("x-admin-api-key") || "";
  if (!expected || supplied.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(expected))) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}
app.get("/health", (_req, res) => res.json({ ok: true, service: "easy-ps-api-starter" }));
app.use("/api", adminAuth);

app.get("/api/clients", (_req, res) => res.json([...clients.values()]));
app.post("/api/clients", (req, res) => {
  const c = req.body || {};
  if (!c.name || !c.phone || !["Phone", "SMS"].includes(c.kind) ||
      !c.date || !c.time || !c.message || c.consent !== true) {
    return res.status(400).json({ error: "Required fields missing; explicit consent is required." });
  }
  const item = { id: crypto.randomUUID(), ...c, status: "Scheduled", createdAt: new Date().toISOString() };
  clients.set(item.id, item);
  res.status(201).json(item);
});
app.delete("/api/clients/:id", (req, res) => {
  clients.delete(req.params.id);
  res.status(204).end();
});
app.post("/api/jobs/:id/attempt", (req, res) => {
  // Deliberately a stub: no real SIM/API call is made by this starter.
  // Production implementation must check consent, opt-out, quiet hours,
  // idempotency, rate limits and provider/device authorization.
  const c = clients.get(req.params.id);
  if (!c) return res.status(404).json({ error: "Client not found" });
  if (c.consent !== true || c.optedOut === true) return res.status(409).json({ error: "No valid consent / recipient opted out" });
  const job = { id: crypto.randomUUID(), clientId: c.id, policy: "SIM_FIRST_API_FALLBACK", state: "QUEUED_NOT_SENT", createdAt: new Date().toISOString() };
  jobs.set(job.id, job);
  res.status(202).json({ ...job, message: "Queued in starter only; no call or SMS was sent." });
});
app.get("/api/jobs", (_req, res) => res.json([...jobs.values()]));
const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`Easy PS API starter listening on ${port}`));
