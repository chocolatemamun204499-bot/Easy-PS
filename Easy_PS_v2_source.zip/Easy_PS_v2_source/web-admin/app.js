async function loadClients(){
 const base=document.getElementById("base").value.replace(/\/$/,"");
 const key=document.getElementById("key").value;
 const out=document.getElementById("out");
 if(!base||!key){out.textContent="Enter backend URL and admin API key.";return;}
 out.textContent="Loading…";
 try{
  const r=await fetch(base+"/api/clients",{headers:{"x-admin-api-key":key}});
  const data=await r.json();
  if(!r.ok) throw new Error(data.error||r.statusText);
  out.textContent=JSON.stringify(data,null,2);
 }catch(e){out.textContent="Could not load: "+e.message;}
}