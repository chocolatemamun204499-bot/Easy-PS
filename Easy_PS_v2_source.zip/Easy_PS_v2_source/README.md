# Easy PS v2 — Android + Web Admin starter source

This is a **starter source project**, not a compiled APK or deployed website.

## Included
- Android Studio Kotlin/Jetpack Compose starter app
- Client form with name, phone, Phone/SMS type, date/time, message and consent
- Local in-memory demo list (replace with Room + cloud sync for production)
- Responsive web-admin starter page that connects to a configurable backend URL
- Node/Express API skeleton with client CRUD and scheduled-job endpoints
- Provider adapter placeholders for SIM and approved Voice/SMS API

## Build the Android app
1. Install Android Studio (current stable).
2. Open the `android/` folder.
3. Let Gradle sync.
4. Run on an Android test device.

The project is a development starter. It has not been built or tested against a device in this environment.

## Run the backend
1. Install Node.js 20+.
2. In `backend/`, run `npm install`.
3. Copy `.env.example` to `.env` and configure a strong `ADMIN_API_KEY`.
4. Run `npm start`.

The API uses an in-memory store in this starter. Replace it with PostgreSQL before real use.

## Run the web admin
Serve `web-admin/` with any static web server and set `API_BASE` in `app.js` to your backend URL.

## Important production requirements
- Add real admin authentication (prefer managed identity/OAuth, not a shared hard-coded key).
- Use PostgreSQL, encrypted secrets, HTTPS, backups and audit logs.
- Implement opt-out/suppression, consent records, per-recipient rate limits, quiet hours, duplicate prevention and delivery status callbacks.
- The default SIM path must be implemented only through Android-supported user-authorized flows and applicable carrier/platform rules. Android background calling and SMS restrictions vary; some distribution channels require the app to be the default SMS handler or use an approved role/permission.
- API fallback requires an approved provider account and credentials. No provider is selected or configured here.
- Never send to a recipient who has opted out. “Unlimited” delivery cannot be guaranteed; carriers and providers impose limits.
- Do not use for unsolicited bulk calls or messages.

## Routing design
`SIM first → API fallback` is represented as a routing policy in the data model. The starter does not perform live sending. A production worker should:
1. Verify consent, schedule, quiet hours and suppression status.
2. Attempt the permitted SIM route when the device and OS allow it.
3. Record the provider/device result.
4. On a qualifying failure, enqueue one API fallback attempt.
5. Prevent duplicate delivery with an idempotency key.
