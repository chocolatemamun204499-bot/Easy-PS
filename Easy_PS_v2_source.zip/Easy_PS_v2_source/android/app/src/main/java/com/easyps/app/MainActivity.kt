package com.easyps.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

data class Client(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String,
    val kind: String,
    val date: String,
    val time: String,
    val message: String,
    val consent: Boolean,
    val route: String = "SIM first → API fallback"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EasyPsScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EasyPsScreen() {
    val clients = remember { mutableStateListOf<Client>() }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("SMS") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var time by remember { mutableStateOf(LocalTime.now().withSecond(0).toString()) }
    var message by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Prototype mode — live calls/SMS are not connected.") }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("Easy PS") }, subtitle = { Text("Client & Reminder Manager") })
        }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ElevatedCard(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) {
                        Text("${clients.size}", style = MaterialTheme.typography.headlineMedium)
                        Text("Clients")
                    } }
                    ElevatedCard(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) {
                        Text("500+", style = MaterialTheme.typography.headlineMedium)
                        Text("Expandable target")
                    } }
                }
                Spacer(Modifier.height(14.dp))
                Text("Add client", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(name, { name = it }, label = { Text("Client name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone number") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = kind == "SMS", onClick = { kind = "SMS" }, label = { Text("SMS") })
                    FilterChip(selected = kind == "Phone", onClick = { kind = "Phone" }, label = { Text("Phone") })
                }
                OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(time, { time = it }, label = { Text("Time (HH:MM)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(message, { message = it }, label = { Text("SMS text / voice script") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Row {
                    Checkbox(checked = consent, onCheckedChange = { consent = it })
                    Text("Client has agreed to receive this reminder", modifier = Modifier.padding(top = 12.dp))
                }
                Button(onClick = {
                    if (name.isBlank() || phone.isBlank() || message.isBlank() || !consent) {
                        notice = "Name, phone, message and recorded consent are required."
                    } else {
                        clients.add(Client(name = name.trim(), phone = phone.trim(), kind = kind, date = date, time = time, message = message.trim(), consent = consent))
                        name = ""; phone = ""; message = ""; consent = false
                        notice = "Client saved locally. Live delivery is not enabled."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Save client") }
                Spacer(Modifier.height(8.dp))
                Text(notice, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Text("Client list", style = MaterialTheme.typography.titleLarge)
                LazyColumn {
                    items(clients) { c ->
                        ListItem(
                            headlineContent = { Text(c.name) },
                            supportingContent = { Text("${c.phone} • ${c.kind} • ${c.date} ${c.time}") },
                            trailingContent = { Text("Scheduled") }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
